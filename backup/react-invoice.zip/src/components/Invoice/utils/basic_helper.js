export function randomNumber() {
  return Math.floor(Math.random() * 9999);
}
