const tokenUrl =
  "https://us1.pusherplatform.io/services/chatkit_token_provider/v1/6a0c34b1-f48f-4a75-8cf2-f872cee678e6/token";
const instanceLocator = "v1:us1:6a0c34b1-f48f-4a75-8cf2-f872cee678e6";
const secretKey =
  "cb83a7c1-2ad3-401d-a628-1bec52481bdd:tOtNcTTarjwjt24eCt7vTUPaHvqwV+HCjBEvuM5lZPk=";

export { tokenUrl, instanceLocator, secretKey };
