import React, { Component } from "react";

class RoomList extends Component {
  render() {
    return (
      <div className="room-list">
        <h4>Room List</h4>
      </div>
    );
  }
}

export default RoomList;
