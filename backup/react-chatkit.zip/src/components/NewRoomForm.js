import React, { Component } from "react";

class NewRoomForm extends Component {
  render() {
    return (
      <div className="new-room-form">
        <h4>New Room Form</h4>
      </div>
    );
  }
}

export default NewRoomForm;
