import React, { Component } from "react";

class SendMessageForm extends Component {
  render() {
    return (
      <div className="send-message-form">
        <h4>Send Message Form</h4>
      </div>
    );
  }
}

export default SendMessageForm;
