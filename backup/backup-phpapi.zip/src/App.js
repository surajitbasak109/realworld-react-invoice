import React from "react";
import { BrowserRouter } from "react-router-dom";
import Navbar from "./components/Navbar";
import Router from "./Router";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      messages: []
    };
  }

  componentDidMount() {}

  render() {
    return (
      <BrowserRouter>
        <div className="app">
          <Navbar />
          <Router />
        </div>
      </BrowserRouter>
    );
  }
}

export default App;
