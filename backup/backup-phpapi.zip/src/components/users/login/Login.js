import React, { Component } from "react";

class Login extends Component {
  constructor(props) {
    super(props);

    this.state = {
      email: "",
      password: ""
    };

    this.login = this.login.bind(this);
    this.onChange = this.onChange.bind(this);
  }
  onChange(e) {
    this.setState({
      [e.target.name]: e.target.value
    });
  }
  login() {
    console.log("Form submitted");
  }
  render() {
    return (
      <div>
        <div className="card card-body shadow mt-3 col-md-6 offset-md-3">
          <div className="row">
            <div className="col-12">
              <h1 className="text-center">Sign In</h1>
              <form className="form-signin mt-4">
                <div className="form-group">
                  <label htmlFor="emailInput">Email</label>
                  <input
                    name="email"
                    id="emailInput"
                    type="email"
                    className="form-control"
                    placeholder="Email address"
                    required
                    autoFocus
                    value={this.state.email}
                    onChange={this.onChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="passwordInput">Password</label>
                  <input
                    name="password"
                    id="passwordInput"
                    type="password"
                    className="form-control"
                    placeholder="Password"
                    required
                    value={this.state.password}
                    onChange={this.onChange}
                  />
                </div>

                <button
                  className="btn btn-lg btn-primary btn-block"
                  type="button"
                  onClick={this.login}
                >
                  Sign in
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Login;
